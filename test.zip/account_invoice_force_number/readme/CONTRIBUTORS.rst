* Alex Comba <alex.comba@agilebg.com> (https://www.agilebg.com/)
* Francesco Apruzzese <f.apruzzese@apuliasoftware.it>
* Rattapong Chokmasermkul <rattapongc@ecosoft.co.th>
* Simone Vanin <simone.vanin@agilebg.com> (https://www.agilebg.com/)
