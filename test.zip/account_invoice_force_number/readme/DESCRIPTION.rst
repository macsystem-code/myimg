This module allows to force the invoice numbering. It displays the move_name field.
If user fills that field, the typed value will be used as invoice (and move) number.
Otherwise, the next sequence number will be retrieved and saved.
So, the new field has to be used when user doesn't want to use the default invoice numbering for a specific invoice.
