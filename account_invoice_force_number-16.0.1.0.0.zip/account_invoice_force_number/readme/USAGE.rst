Once installed, you'll find the Force Number field on all the invoices in draft state.
You can then fill in this field with the invoice number you want to assign.
The invoice will get this number when confirmed.
